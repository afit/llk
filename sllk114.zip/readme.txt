LothianLite Kit
===============

The LothianLite Kit is a powerful and fast set of ActiveX controls for Win32 developers. It contains button, non-modal button, panel, label, check-box, text-box, divider and caption controls. These are all built around a core appearance engine to ensure they all match in their customisable appearances. The controls can look like Windows '95 or '98 buttons, or use over 24 over custom styles.

This product takes the form of an ActiveX control set.

Developer documentation can be found at:

http://www.reincubate.com

Important disclaimer
====================

THIS PROGRAM AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

== IF YOUR CHOSEN INSTALLATION TYPE DIDN'T INCLUDE A SETUP.EXE FILE, PLEASE READ THE FOLLOWING:

Installation
============

If the .OCX file has been kept in the C:\WINNT\SYSTEM32 folder, it can be registered with:

regsvr32 c:\winnt\system32\sllk.ocx

If this is successfull it will be available as an embeddable ActiveX control.

Uninstallation
==============

The command (replace C:\WINNT\SYSTEM32 with the file's path):

regsvr32 c:\winnt\system32\sllk.ocx /u

Will unregister the file so that it can be successfully deleted.
